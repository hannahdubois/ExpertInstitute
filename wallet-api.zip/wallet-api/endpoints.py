import requests
from flask import Flask
from flask_cors import CORS
from core import *

app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*"}})


@app.route('/wallet/assets', methods=['GET'])
def apiGetAssets():
    return jsonify(getAssets())


@app.route('/wallet/asset/<assetId>', methods=['GET'])
def apiGetAssetById(assetId):
    return jsonify(getAssetById(assetId))


@app.route('/wallet/asset/add', methods=['POST'])
def apiAddAsset():
    asset = request.json
    return jsonify(addAsset(asset))

@app.route('/wallet/asset/update', methods=['PUT'])
def apiUpdateAsset():
    asset = request.get_json()
    return jsonify(updateAsset(asset))


@app.route('/wallet/asset/delete/<assetId>', methods=['DELETE'])
def apiDeleteAsset(assetId):
    return jsonify(deleteAsset(assetId))

@app.route('/wallet/asset/convert/<assetId>',methods = ['GET'])
def apiConvertValueForAsset(assetId):
    return jsonify(convertAsset(assetId))


if __name__ == "__main__":
    app.debug = True
    app.run()


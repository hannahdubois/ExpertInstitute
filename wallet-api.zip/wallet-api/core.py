import json
import sqlite3
import requests

from flask import Flask, jsonify, request

allAssets = []


def createDatabase():
    conn = sqlite3.connect('assets.db')
    cur = conn.cursor()
    cur.execute("CREATE table asset (asset_id INTEGER PRIMARY KEY NOT NULL, name TEXT NOT NULL, value INTEGER NOT "
                "NULL);")
    conn.commit()
    conn.close()


def connectToDatabase():
    conn = sqlite3.connect("assets.db")
    return conn


def addAsset(asset):
    insertedAsset = {}
    # try:
    #     conn = connectToDatabase()
    #     cur = conn.cursor()
    #     cur.execute("INSERT INTO asset (name, value) VALUES (?,?)", (asset['name'], asset['value']))
    #     # insertedAsset = getAssetById(cur.lastrowid)
    for item in allAssets:
        if item['name'] == asset['name']:
            return "Error: This asset has already been added to your wallet!"
    insertedAsset = asset
    allAssets.append(asset)
    # except:
    #     conn.rollback()
    # finally:
    #     conn.close()
    return insertedAsset


def getAssetById(assetId):
    asset = {}
    # try:
        # conn = connectToDatabase()
        # conn.row_factory = sqlite3.Row
        # cur = conn.cursor()
        # cur.execute("SELECT * from asset where name = ?", (assetId))
        # row = cur.fetchone()
    for item in allAssets:
        if item['name'] == assetId:
            asset = item
    if asset == {}:
        return "Error: asset " + assetId + " is not in your wallet!"
        # asset['name'] = row['name']
        # asset['value'] = row['value']
    # except:
    #     asset = {}
    return asset


def getAssets():
    assets = []
    # try:
    #     conn = connectToDatabase()
    #     conn.row_factory = sqlite3.Row
    #     cur = conn.cursor()
    #     cur.execute("SELECT * FROM asset")
    #     rows = cur.fetchall()
    #     for i in rows:
    #         asset = {"name": i["name"], "value": i["value"]}
    #         assets.append(asset)

    # except:
    #     assets = []
    return allAssets


def updateAsset(asset):
    updatedAssets = {}
    #try:
        #   conn = connectToDatabase()
        #   cur = conn.cursor()
        #   cur.execute("UPDATE asset SET value = ? where name = ?", (asset["name"]))
        #   conn.commit()
        #   updatedAssets = getAssetById(asset["name"])

    for item in allAssets:
        if item['name'] == asset['name']:
            item['value'] = asset['value']
            updatedAssets = item
    if updatedAssets == {}:
        return "Error: the asset " + asset['name'] + " is not in your wallet!"
    #except:
        # conn.rollback()
        #updatedAssets = {}
    # finally:
    # conn.close()
    return updatedAssets


def deleteAsset(assetId):
    message = "Error: Delete was unsuccessful"
    # try:
        # conn = connectToDatabase()
        # conn.execute("DELETE from asset WHERE name = ?", (assetId))
        # conn.commit()
        # message = "Asset deleted Successfully"

    for item in allAssets:
        if item['name'] == assetId:
            allAssets.remove(item)
            message = item['name'] + ' successfully deleted'
    # except:
    #     conn.rollback()
    # finally:
    #     conn.close()
    return message

def convertAsset(assetId):
    url = "http://api.coincap.io/v2/assets/" + assetId
    resp = requests.get(url)
    if resp.status_code == 200:
        jsonObj = json.loads(resp.text)
        print(jsonObj)
        priceUsd = float(jsonObj['data']['priceUsd'])
        asset = getAssetById(assetId)
        usd = "{:.2f}".format(priceUsd * asset['value'])
    else:
        return "Error: There was a problem accessing the Coincap api for conversion information!"
    return usd




if __name__ == "__main__":
    # createDatabase()
    print(addAsset({'name': 'bitcoin', 'value': 200}))
    print(convertAsset('bitcoin'))
    #print(getAssets())
    #print(updateAsset({'name': 'bitcoin', 'value': 300}))
    #print(getAssets())
    #print(deleteAsset('bitcoin'))
    #print(getAssets())



import requests
import logging
from flask import jsonify


def testGetAssets():
    url = 'http://127.0.0.1:5000/wallet/assets'
    resp = requests.get(url)
    print(resp.text)
    print(resp.status_code)


def testCreateAsset(name, value):
    d = {'name': name, 'value': value}
    url = 'http://127.0.0.1:5000/wallet/asset/add'
    resp = requests.post(url, None, json=d)
    print(resp.text)
    print(resp.status_code)


def testUpdateAsset(name, value):
    d = {'name': name, 'value': value}
    url = 'http://127.0.0.1:5000/wallet/asset/update'
    resp = requests.put(url, None, json=d)
    print(resp.text)
    print(resp.status_code)


def testDeleteAsset(name):
    url = 'http://127.0.0.1:5000/wallet/asset/delete/' + name
    resp = requests.delete(url)
    print(resp.text)
    print(resp.status_code)


def testGetAssetById(name):
    url = 'http://127.0.0.1:5000/wallet/asset/' + name
    resp = requests.get(url)
    print(resp.text)
    print(resp.status_code)


def testConvertAsset(name):
    url = 'http://127.0.0.1:5000/wallet/asset/convert/' + name
    resp = requests.get(url)
    print(resp.text)
    print(resp.status_code)


if __name__ == "__main__":
    testCreateAsset('bitcoin', 10)
    testGetAssets()
    testGetAssetById('bitcoin')
    # testUpdateAsset('bitcoin', 3000)
    # testGetAssets()
    # testDeleteAsset('bitcoin')
    testConvertAsset('bitcoin')

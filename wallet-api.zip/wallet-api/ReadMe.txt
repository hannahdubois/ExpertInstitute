Thank you so much for the opportunity to complete this assignment. I really enjoyed learning more about using Python
and Flask for creating APIs.

This project includes:
 1. a tests.py file, where I have created tests to call the api endpoints.
 2. endpoints.py file, where all of the endpoints of the api are located and the start of the application.
 To run the application. Run python3 endpoints.py
 3. core.py file, where I have the logic work for the api
 4. assets.db file, the database file I was planning to use to store the wallet data.

 Approach:

 1. I planned to create the CRUD of the api using Python, Flask and Sqlite3. I spent a majority of the first two days
 testing and working on the database; however, I found that when I tried to connect to the database to insert into
 the table I created I got database connection errors. With more time and a few more database tools, I think I could
 have gotten the database working.

 2. When the database didn't quite work out, I went to a more basic CRUD design using a global list
  to store the assets created. I planned to write the list to a file and then read the data after. My plan at first
  was to create an endpoint to open the assets ( pull the assets from the file) and an endpoint to save assets (write
  assets to a file). I did not implement this, but I think it would be fairly simple to implement.

 3. I used the Coincap api GET/assets/{{id}} for the conversion endpoint, to allow users to convert their assets to USD.

 Future Additions/ Reflections:

 Next time, I would focus less on getting the database set up and more on a basic CRUD implemention using a global list
 with endpoints to save and open the previous runs assets. I would also add more information to my responses by using more
 of the coincap api data. I think it would be more interesting to see more information on the assets, such as the symbol,
 and 24 hour changes. I would also add more robust error handling (rather than returning strings) and I would look more
 into how to send a bad response back purposely.

 I did leave (commented out) sections of code where I was attempting to get my database set up. I have used similar
 commands in Java to run sql commands, but I am still learning more about Sqlite3 and python databases.






